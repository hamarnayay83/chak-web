/* ============================================================
   🚀 MAIN.JS — سکریپتی سەرەکی (بەشی ئەدمینیش تێدایە)
   ============================================================ */

const STORAGE_KEYS = 'khama_website_keys_v1';
const ADMIN_USERNAME = "hamaa";
const ADMIN_PASSWORD = "0011";

/* ============================================================
   🔐 AUTH (بۆ بەکارهێنەر)
   ============================================================ */
function checkAuth() {
    const sessionData = localStorage.getItem('userSession');
    if (!sessionData) return null;
    try {
        const session = JSON.parse(sessionData);
        if (Date.now() > session.expiresAt) {
            localStorage.removeItem('userSession');
            return null;
        }
        return session;
    } catch (e) {
        localStorage.removeItem('userSession');
        return null;
    }
}

function updateAuthUI(isLoggedIn) {
    const sessionInfo = document.getElementById('sessionInfo');
    const sidebarLogout = document.getElementById('sidebarLogoutBtn');
    const mobileLogout = document.getElementById('mobileLogoutBtn');
    if (isLoggedIn) {
        if (sessionInfo) sessionInfo.style.display = 'block';
        if (sidebarLogout) sidebarLogout.style.display = 'flex';
        if (mobileLogout) mobileLogout.style.display = 'flex';
    } else {
        if (sessionInfo) sessionInfo.style.display = 'none';
        if (sidebarLogout) sidebarLogout.style.display = 'none';
        if (mobileLogout) mobileLogout.style.display = 'none';
    }
}

function requireAuth(targetView) {
    const session = checkAuth();
    if (!session) {
        localStorage.setItem('redirectAfterAuth', targetView);
        window.location.href = 'auth.html';
        return false;
    }
    return true;
}

function logout() {
    if (!confirm('ئایا دڵنیایت لە دەرچوون؟')) return;
    localStorage.removeItem('userSession');
    updateAuthUI(false);
    window.location.href = 'index.html';
}

function showSessionInfo() {
    const sessionData = localStorage.getItem('userSession');
    const infoEl = document.getElementById('sessionInfo');
    if (!sessionData || !infoEl) return;
    try {
        const session = JSON.parse(sessionData);
        const daysLeft = Math.max(0, Math.ceil((session.expiresAt - Date.now()) / (1000 * 60 * 60 * 24)));
        const planNames = { 'day': '١ ڕۆژ', 'week': '٧ ڕۆژ', 'month': '٣٠ ڕۆژ', 'halfyear': '٦ مانگ', 'year': '١ ساڵ' };
        const planName = planNames[session.plan] || session.plan;
        let checksLeft = session.checksLeft;
        if (checksLeft === undefined) {
            checksLeft = 2; session.checksLeft = 2; session.checksUsed = 0; session.checksTotal = 2;
            localStorage.setItem('userSession', JSON.stringify(session));
        }
        const checksUsed = session.checksUsed || 0;
        const checksDisplay = (checksLeft === 99) ? '∞' : checksLeft;
        infoEl.innerHTML = `
            <div class="session-badge">
                <div class="session-status">🟢 چالاک</div>
                <div class="session-plan">📦 ${planName}</div>
                <div class="session-days">⏳ ${daysLeft} ڕۆژ ماوە</div>
                <div class="session-checks">🔍 چەیک: ${checksDisplay} ماوە (${checksUsed} بەکارهاتوو)</div>
            </div>`;
    } catch (e) {}
}

/* ============================================================
   🔍 CHECKS
   ============================================================ */
function getChecksLeft() {
    const sessionData = localStorage.getItem('userSession');
    if (!sessionData) return 0;
    try {
        const session = JSON.parse(sessionData);
        return session.checksLeft;
    } catch (e) { return 0; }
}

function canUseCheck() {
    const checksLeft = getChecksLeft();
    return checksLeft === 99 || checksLeft > 0;
}

async function useCheck() {
    const sessionData = localStorage.getItem('userSession');
    if (!sessionData) return false;
    try {
        const session = JSON.parse(sessionData);
        const isUnlimited = session.checksLeft === 99 || session.checksTotal === 99;
        if (isUnlimited || session.checksLeft > 0) {
            if (!isUnlimited) session.checksLeft -= 1;
            session.checksUsed = (session.checksUsed || 0) + 1;
            localStorage.setItem('userSession', JSON.stringify(session));
            try {
                const raw = localStorage.getItem(STORAGE_KEYS);
                if (raw) {
                    const data = JSON.parse(raw);
                    const k = (data.keys || []).find(x => x.id === session.keyId);
                    if (k) {
                        k.checks_used = session.checksUsed;
                        localStorage.setItem(STORAGE_KEYS, JSON.stringify(data));
                    }
                }
            } catch (e) {}
            showSessionInfo();
            return true;
        }
        return false;
    } catch (e) { return false; }
}

function showNoChecksAlert() {
    const msg = `⚠️ چەیکەکانت تەواو بوون!\n\n💡 چارەسەر:\nلە بەشی "کڕین و نرخ" پاکێجێکی نوێ بکڕە.`;
    if (confirm(msg)) {
        const nav = document.querySelector('[data-view=pricing]');
        if (nav) switchView('pricing', nav);
    }
}

/* ============================================================
   🛒 PURCHASE
   ============================================================ */
const TELEGRAM_USERNAME = "i4xhama";

function buyPackage(plan, price) {
    const planNames = { 'day': 'یەک ڕۆژ', 'week': 'حەفتەیەک', 'month': 'مانگێک', 'halfyear': '٦ مانگ', 'year': 'یەک ساڵ' };
    const message = `🛒 داواکاری کڕینی پاکێج\n\n📦 پاکێج: ${planNames[plan]}\n💰 نرخ: ${price.toLocaleString('ar-IQ')} دینار\n\n━━━━━━━━━━━━━━━━\nتکایە ئەم پاکێجە بۆ من ڕێک بکە.`;
    sendToTelegram(message);
}

function buyChecks(count, price) {
    const message = `🛒 داواکاری کڕینی چەیک\n\n🔍 ژمارەی چەیک: ${count} چەیک\n💰 نرخ: ${price.toLocaleString('ar-IQ')} دینار\n\n━━━━━━━━━━━━━━━━\nتکایە ئەم چەیکانە بۆ من ڕێک بکە.`;
    sendToTelegram(message);
}

function sendToTelegram(message) {
    if (navigator.clipboard) navigator.clipboard.writeText(message);
    const tgUrl = `https://t.me/${TELEGRAM_USERNAME}`;
    showTelegramModal(message, tgUrl);
}

function showTelegramModal(message, tgUrl) {
    const oldModal = document.getElementById('telegramModal');
    if (oldModal) oldModal.remove();
    const modal = document.createElement('div');
    modal.id = 'telegramModal';
    modal.style.cssText = `position: fixed; inset: 0; background: rgba(0,0,0,0.85); backdrop-filter: blur(10px); z-index: 99999; display: flex; align-items: center; justify-content: center; padding: 20px; direction: rtl;`;
    modal.innerHTML = `
        <div style="background: rgba(255,255,255,0.06); backdrop-filter: blur(40px); border: 1px solid rgba(255,255,255,0.15); border-radius: 24px; padding: 35px 28px; max-width: 480px; width: 100%; text-align: center; font-family: 'Vazirmatn', sans-serif;">
            <h2 style="font-size: 1.4rem; color: #fff; margin-bottom: 10px;">نامەکە ئامادەیە!</h2>
            <p style="color: #94a3b8; font-size: 0.9rem; margin-bottom: 22px;">نامەکەت کۆپی کرا. Paste بکە لە تیلیگرام و Send بکە.</p>
            <a href="${tgUrl}" target="_blank" style="display: block; width: 100%; padding: 16px; background: linear-gradient(135deg, #229ed9, #0088cc); color: #fff; text-decoration: none; border-radius: 14px; font-weight: 800;">چوونە ناو تیلیگرام</a>
            <button onclick="document.getElementById('telegramModal').remove()" style="margin-top: 10px; background: transparent; color: #94a3b8; border: none; cursor: pointer;">داخستن</button>
        </div>
    `;
    document.body.appendChild(modal);
}

/* ============================================================
   🎨 UI
   ============================================================ */
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
    document.querySelector('.sidebar-overlay').classList.toggle('active');
}

function switchView(type, btn) {
    if (type === 'site' || type === 'code' || type === 'learn') {
        if (!requireAuth(type)) return;
    }
    document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.content-panel').forEach(el => el.classList.remove('active'));
    const mainOutput = document.getElementById('mainOutputContainer');
    if (mainOutput) mainOutput.innerHTML = '';
    const heroCards = document.getElementById('heroCards');
    const heroHeader = document.getElementById('heroHeader');
    if (heroCards) heroCards.style.display = 'none';
    if (heroHeader) heroHeader.style.display = 'none';
    if (btn) btn.classList.add('active');
    const panelMap = {
        'site': 'siteViewPanel', 'code': 'codeViewPanel', 'profile': 'profileViewPanel',
        'learn': 'learnViewPanel', 'pricing': 'pricingViewPanel'
    };
    const panelId = panelMap[type];
    if (panelId) {
        const panel = document.getElementById(panelId);
        if (panel) panel.classList.add('active');
    }
    if (window.innerWidth <= 768) {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.querySelector('.sidebar-overlay');
        if (sidebar) sidebar.classList.remove('open');
        if (overlay) overlay.classList.remove('active');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function switchLearnTab(tabName, btn) {
    document.querySelectorAll('.sub-tab').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.learn-section').forEach(el => el.classList.remove('active'));
    btn.classList.add('active');
    const target = document.getElementById('learn-' + tabName);
    if (target) target.classList.add('active');
}

const palettes = {
    1: { primary: '#4f9dff', primarySoft: '#7db8ff', primaryGlow: 'rgba(79,157,255,0.35)', accent: '#a78bfa', bgDeep: '#060810', bgAnim1: 'rgba(79,157,255,0.15)', bgAnim2: 'rgba(167,139,250,0.12)', bgAnim3: 'rgba(52,211,153,0.1)' },
    2: { primary: '#ff6a00', primarySoft: '#ffa94d', primaryGlow: 'rgba(255,106,0,0.4)', accent: '#ffd200', bgDeep: '#120804', bgAnim1: 'rgba(255,106,0,0.2)', bgAnim2: 'rgba(255,210,0,0.15)', bgAnim3: 'rgba(255,75,43,0.12)' },
    3: { primary: '#00c6ff', primarySoft: '#66d9ff', primaryGlow: 'rgba(0,198,255,0.4)', accent: '#00f2fe', bgDeep: '#040c16', bgAnim1: 'rgba(0,198,255,0.2)', bgAnim2: 'rgba(0,242,254,0.15)', bgAnim3: 'rgba(79,172,254,0.12)' },
    4: { primary: '#38ef7d', primarySoft: '#7dffb0', primaryGlow: 'rgba(56,239,125,0.4)', accent: '#f9d423', bgDeep: '#04100a', bgAnim1: 'rgba(56,239,125,0.2)', bgAnim2: 'rgba(249,212,35,0.15)', bgAnim3: 'rgba(17,153,142,0.12)' },
    5: { primary: '#ee0979', primarySoft: '#ff5ca8', primaryGlow: 'rgba(238,9,121,0.4)', accent: '#c471ed', bgDeep: '#12060c', bgAnim1: 'rgba(238,9,121,0.2)', bgAnim2: 'rgba(196,113,237,0.15)', bgAnim3: 'rgba(255,106,0,0.12)' },
    6: { primary: '#4facfe', primarySoft: '#8ccfff', primaryGlow: 'rgba(79,172,254,0.4)', accent: '#a18cd1', bgDeep: '#060814', bgAnim1: 'rgba(79,172,254,0.2)', bgAnim2: 'rgba(161,140,209,0.15)', bgAnim3: 'rgba(251,194,235,0.1)' }
};

function applyPalette(num, btn) {
    const p = palettes[num];
    if (!p) return;
    const root = document.documentElement;
    root.style.setProperty('--primary', p.primary);
    root.style.setProperty('--primary-soft', p.primarySoft);
    root.style.setProperty('--primary-glow', p.primaryGlow);
    root.style.setProperty('--accent', p.accent);
    root.style.setProperty('--bg-deep', p.bgDeep);
    root.style.setProperty('--bg-anim-1', p.bgAnim1);
    root.style.setProperty('--bg-anim-2', p.bgAnim2);
    root.style.setProperty('--bg-anim-3', p.bgAnim3);
    document.querySelectorAll('.palette-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    localStorage.setItem('sentinelPalette', num);
}

/* ============================================================
   👑 ADMIN — بەشی ئەدمین (لە index.html)
   ============================================================ */
function openAdminLogin() {
    document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.content-panel').forEach(el => el.classList.remove('active'));
    const heroCards = document.getElementById('heroCards');
    const heroHeader = document.getElementById('heroHeader');
    if (heroCards) heroCards.style.display = 'none';
    if (heroHeader) heroHeader.style.display = 'none';
    const mainOutput = document.getElementById('mainOutputContainer');
    if (mainOutput) mainOutput.innerHTML = '';
    
    // ئەگەر پێشتر لۆگین کرابوو
    if (sessionStorage.getItem('adminLoggedIn') === 'true') {
        document.getElementById('adminViewPanel').classList.add('active');
        loadAdminKeys();
    } else {
        document.getElementById('adminLoginPanel').classList.add('active');
    }
    
    document.querySelectorAll('.nav-item').forEach(el => {
        if (el.classList.contains('admin-nav')) el.classList.add('active');
    });
    
    if (window.innerWidth <= 768) {
        document.getElementById('sidebar').classList.remove('open');
        document.querySelector('.sidebar-overlay').classList.remove('active');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function adminLogin() {
    const username = document.getElementById('adminUsername').value.trim();
    const password = document.getElementById('adminPassword').value.trim();
    const msg = document.getElementById('adminLoginMsg');
    
    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
        sessionStorage.setItem('adminLoggedIn', 'true');
        msg.style.display = 'none';
        document.getElementById('adminUsername').value = '';
        document.getElementById('adminPassword').value = '';
        document.getElementById('adminLoginPanel').classList.remove('active');
        document.getElementById('adminViewPanel').classList.add('active');
        loadAdminKeys();
    } else {
        msg.className = 'admin-login-msg error';
        msg.style.display = 'block';
        msg.textContent = '❌ ناوی بەکارهێنەر یان پاسوەرد هەڵەیە!';
    }
}

function adminLogout() {
    if (!confirm('ئایا دڵنیایت لە دەرچوون لە پانێڵی ئەدمین؟')) return;
    sessionStorage.removeItem('adminLoggedIn');
    openAdminLogin();
}

/* ============================================================
   👑 ADMIN — کلیلەکان
   ============================================================ */
function getAdminKeys() {
    try {
        const raw = localStorage.getItem(STORAGE_KEYS);
        if (raw) {
            const data = JSON.parse(raw);
            return data.keys || [];
        }
    } catch (e) {
        console.warn('هەڵە لە خواندنی داتا:', e);
    }
    return [];
}

function saveAdminKeys(keys) {
    const data = {
        keys: keys,
        lastUpdated: new Date().toISOString()
    };
    localStorage.setItem(STORAGE_KEYS, JSON.stringify(data));
}

function loadAdminKeys() {
    let keys = getAdminKeys();
    if (keys.length === 0) {
        fetch('keys.json')
            .then(r => {
                if (!r.ok) throw new Error('فایل نەدۆزرایەوە');
                return r.json();
            })
            .then(data => {
                if (data && data.keys && data.keys.length > 0) {
                    localStorage.setItem(STORAGE_KEYS, JSON.stringify(data));
                    renderAdminKeys(data.keys);
                } else {
                    renderAdminKeys([]);
                }
                document.getElementById('downloadPanel').style.display = 'block';
            })
            .catch(err => {
                console.log('keys.json نەدۆزرایەوە — دەستپێکردنی بەتاڵ:', err.message);
                renderAdminKeys([]);
                document.getElementById('downloadPanel').style.display = 'block';
            });
    } else {
        renderAdminKeys(keys);
        document.getElementById('downloadPanel').style.display = 'block';
    }
}

function generateRandomKey() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
    let k = '';
    for (let i = 0; i < 12; i++) k += chars.charAt(Math.floor(Math.random() * chars.length));
    return k;
}

function getDurationDays(plan) {
    const map = { 'day': 1, 'week': 7, 'month': 30, 'halfyear': 180, 'year': 365 };
    return map[plan] || 30;
}

function getAdminPlanName(plan) {
    const map = { 'day': '١ ڕۆژ', 'week': '٧ ڕۆژ', 'month': '٣٠ ڕۆژ', 'halfyear': '٦ مانگ', 'year': '١ ساڵ' };
    return map[plan] || plan;
}

let lastCreatedKey = '';

function createNewKey() {
    try {
        const plan = document.getElementById('planSelect').value;
        const maxDevices = parseInt(document.getElementById('deviceSelect').value);
        const checksTotal = parseInt(document.getElementById('checkSelect').value);
        const customerName = document.getElementById('customerName').value.trim();
        let customKey = document.getElementById('customKey').value.trim();

        if (!customKey) customKey = generateRandomKey();
        if (customKey.length < 8) {
            alert('❌ کلیل دەبێت لانیکەم ٨ پیت بێت!');
            return;
        }

        const keys = getAdminKeys();
        if (keys.some(k => k.key === customKey)) {
            alert('❌ ئەم کلیلە پێشتر بەکارهاتووە!');
            return;
        }

        const now = Date.now();
        const exp = now + getDurationDays(plan) * 24 * 60 * 60 * 1000;

        const newKey = {
            id: 'key_' + now + '_' + Math.random().toString(36).substring(2, 8),
            key: customKey,
            plan: plan,
            max_devices: maxDevices,
            customer_name: customerName,
            created_at: new Date(now).toISOString(),
            expires_at: new Date(exp).toISOString(),
            checks_total: checksTotal,
            checks_used: 0,
            active: true,
            devices: []
        };

        keys.unshift(newKey);
        saveAdminKeys(keys);
        renderAdminKeys(keys);

        document.getElementById('customKey').value = '';
        document.getElementById('customerName').value = '';
        lastCreatedKey = customKey;
        document.getElementById('createdKeyValue').textContent = customKey;
        document.getElementById('createdKeyBox').style.display = 'block';
        document.getElementById('downloadPanel').style.display = 'block';

        copyToClipboard(customKey);
    } catch (err) {
        console.error('هەڵە لە دروستکردن:', err);
        alert('❌ هەڵە: ' + err.message);
    }
}

function copyCreatedKey() {
    if (lastCreatedKey) copyToClipboard(lastCreatedKey);
}

function copyToClipboard(text) {
    try {
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text);
        } else {
            const t = document.createElement('textarea');
            t.value = text;
            document.body.appendChild(t);
            t.select();
            document.execCommand('copy');
            document.body.removeChild(t);
        }
    } catch (e) {}
    showToast('✓ کۆپی کرا!');
}

function showToast(msg) {
    const n = document.createElement('div');
    n.textContent = msg;
    n.style.cssText = 'position:fixed;bottom:30px;left:50%;transform:translateX(-50%);background:linear-gradient(135deg,#34d399,#06b6d4);color:#fff;padding:14px 28px;border-radius:12px;font-weight:800;z-index:9999;font-family:Vazirmatn,sans-serif;';
    document.body.appendChild(n);
    setTimeout(() => n.remove(), 2000);
}

function renderAdminKeys(keys) {
    const listEl = document.getElementById('keysList');
    if (!listEl) return;
    if (!keys || keys.length === 0) {
        listEl.innerHTML = `<div style="text-align:center; padding:30px; color:#64748b;"><div style="font-size:2rem; margin-bottom:10px;">🔑</div><p>هێشتا هیچ کلیلێک دروست نەکراوە</p></div>`;
        return;
    }

    let html = '';
    keys.forEach(key => {
        const now = Date.now();
        const expTime = new Date(key.expires_at).getTime();
        const isExpired = now > expTime;
        let badgeCls = 'admin-badge-active', badgeTxt = '✅ چالاک';
        if (!key.active) { badgeCls = 'admin-badge-inactive'; badgeTxt = '⛔ ناچالاک'; }
        else if (isExpired) { badgeCls = 'admin-badge-expired'; badgeTxt = '⏰ بەسەرچوو'; }

        const daysLeft = Math.ceil((expTime - now) / (1000 * 60 * 60 * 24));
        const daysText = daysLeft > 0 ? `${daysLeft} ڕۆژ ماوە` : 'بەسەرچووە';
        const devCount = (key.devices || []).length;
        const checksDisplay = key.checks_total === 99 ? '∞' : key.checks_total;

        html += `<div class="admin-key-item">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; flex-wrap:wrap; gap:10px;">
                <span class="admin-badge ${badgeCls}">${badgeTxt}</span>
                <span style="font-size:0.75rem; color:#64748b;">${key.customer_name ? '👤 ' + escapeHTML(key.customer_name) : 'بدوون ناو'}</span>
            </div>
            <div style="font-family:'JetBrains Mono',monospace; font-size:0.9rem; color:#7db8ff; margin-bottom:10px; direction:ltr; word-break:break-all;">
                🔑 ${escapeHTML(key.key)}
            </div>
            <div class="admin-key-stats">
                <div><strong>📅 ماوە</strong>${getAdminPlanName(key.plan)}</div>
                <div><strong>⏳ کاتی ماوە</strong>${daysText}</div>
                <div><strong>📱 ئامێر</strong>${devCount} / ${key.max_devices}</div>
                <div><strong>🔐 چەیک</strong>${key.checks_used} / ${checksDisplay}</div>
            </div>
            <div style="display:flex; gap:8px; flex-wrap:wrap;">
                <button class="admin-btn admin-btn-toggle" onclick="toggleKeyActive('${key.id}')">${key.active ? '⛔ ناچالاککردن' : '✅ چالاککردن'}</button>
                <button class="admin-btn admin-btn-danger" onclick="deleteKey('${key.id}')">🗑️ سڕینەوە</button>
            </div>
        </div>`;
    });
    listEl.innerHTML = html;
}

function toggleKeyActive(id) {
    const keys = getAdminKeys();
    const k = keys.find(x => x.id === id);
    if (!k) return;
    k.active = !k.active;
    saveAdminKeys(keys);
    renderAdminKeys(keys);
}

function deleteKey(id) {
    if (!confirm('ئایا دڵنیایت لە سڕینەوەی ئەم کلیلە؟')) return;
    const keys = getAdminKeys().filter(x => x.id !== id);
    saveAdminKeys(keys);
    renderAdminKeys(keys);
}

function clearAllKeys() {
    if (!confirm('⚠️ ئایا دڵنیایت لە سڕینەوەی هەموو کلیلەکان؟')) return;
    saveAdminKeys([]);
    renderAdminKeys([]);
}

function downloadKeysJSON() {
    const keys = getAdminKeys();
    const data = {
        keys: keys,
        lastUpdated: new Date().toISOString()
    };
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'keys.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('✅ keys.json دابەزێنرا! بۆ Netlify ئەپلۆدی بکەرەوە');
}

/* ============================================================
   🚀 INIT
   ============================================================ */
window.addEventListener('DOMContentLoaded', () => {
    const saved = localStorage.getItem('sentinelPalette');
    if (saved) applyPalette(parseInt(saved), document.querySelector('.pal-' + saved));
    const session = checkAuth();
    if (session) {
        updateAuthUI(true);
        showSessionInfo();
    } else {
        updateAuthUI(false);
    }
    const urlParams = new URLSearchParams(window.location.search);
    const view = urlParams.get('view');
    if (view && session) {
        const viewMap = { site: 0, code: 1, pricing: 2, learn: 3, profile: 4 };
        const idx = viewMap[view];
        const navItems = document.querySelectorAll('.nav-item');
        if (idx !== undefined && navItems[idx]) {
            setTimeout(() => switchView(view, navItems[idx]), 150);
        }
    }
});

/* ============================================================
   🌐 WEBSITE INSPECTION
   ============================================================ */
function quickSelectSite(domain) {
    const input = document.getElementById('targetUrlInput');
    if (input) {
        input.value = domain;
        runWebsiteInspection();
    }
}

async function queryDNS(domain, type) {
    try {
        const res = await fetch(`https://dns.google/resolve?name=${encodeURIComponent(domain)}&type=${type}`);
        return await res.json();
    } catch (e) { return {}; }
}

async function checkSpeed(url) {
    const start = performance.now();
    try {
        const controller = new AbortController();
        const t = setTimeout(() => controller.abort(), 4000);
        await fetch(url, { mode: 'no-cors', cache: 'no-store', signal: controller.signal });
        clearTimeout(t);
        return Math.round(performance.now() - start);
    } catch (e) { return null; }
}

async function runWebsiteInspection() {
    if (!requireAuth('site')) return;
    if (!canUseCheck()) { showNoChecksAlert(); return; }
    let raw = document.getElementById('targetUrlInput').value.trim();
    if (!raw) { alert("تکایە ناوی وێبسایتێک بنووسە!"); return; }
    await useCheck();
    const isHttp = raw.toLowerCase().startsWith('http://');
    let fullUrl = raw;
    if (!fullUrl.startsWith('http://') && !fullUrl.startsWith('https://')) fullUrl = 'https://' + fullUrl;
    let domain = '';
    try {
        domain = new URL(fullUrl).hostname.replace(/^www\./i, '');
    } catch (e) { alert("لینکەکە نادروستە"); return; }
    const loader = document.getElementById('loaderSpinner');
    const output = document.getElementById('mainOutputContainer');
    output.innerHTML = '';
    loader.classList.add('active');
    document.getElementById('loaderStatusText').innerText = 'خەریکی پشکنینی سێرڤەر و قەڵغانەکانی وێبسایتەکەین...';
    const [aRec, aaaaRec, txtRec, dmarcRec, mxRec, nsRec, speed] = await Promise.all([
        queryDNS(domain, 'A'), queryDNS(domain, 'AAAA'), queryDNS(domain, 'TXT'),
        queryDNS(`_dmarc.${domain}`, 'TXT'), queryDNS(domain, 'MX'),
        queryDNS(domain, 'NS'), checkSpeed(fullUrl)
    ]);
    loader.classList.remove('active');
    if (!aRec.Answer && aRec.Status === 3) {
        output.innerHTML = `<div class="item-card" style="border-right-color: #f87171;"><div class="item-name">❌ وێبسایت نەدۆزرایەوە</div></div>`;
        return;
    }
    const ip = (aRec.Answer && aRec.Answer.find(r => r.type === 1)?.data) || 'شاراوەیە';
    const ipv6 = (aaaaRec.Answer && aaaaRec.Answer.find(r => r.type === 28)?.data) || null;
    const nsList = nsRec.Answer ? nsRec.Answer.map(a => a.data).join('، ') : 'نەدۆزرایەوە';
    const mxList = mxRec.Answer ? mxRec.Answer.map(a => a.data).slice(0, 3).join('، ') : 'نییە';
    const items = [];
    const infoItems = [{ label: 'ناونیشانی IP', value: ip }];
    if (ipv6) infoItems.push({ label: 'IPی IPv6', value: ipv6 });
    infoItems.push({ label: 'سێرڤەری ناوی (NS)', value: nsList });
    infoItems.push({ label: 'سێرڤەری ئیمەیڵ (MX)', value: mxList });
    if (isHttp) {
        items.push({ name: 'SSL / HTTPS', status: 'weak', text: 'لاوازە (HTTP)', percent: 20, desc: 'وێبسایتەکە بە HTTP کار دەکات.', solution: 'SSL چالاک بکە.' });
    } else {
        items.push({ name: 'SSL / HTTPS', status: 'strong', text: 'بەهێزە', percent: 100, desc: 'بە HTTPS کار دەکات.', solution: 'باشە.' });
    }
    if (speed === null || speed > 900) {
        items.push({ name: 'خێرایی سێرڤەر', status: 'weak', text: speed ? `خاوە (${speed}ms)` : 'سنووردار', percent: 35, desc: 'وەڵامدانەوەی خاو.', solution: 'CDN بەکاربهێنە.' });
    } else {
        items.push({ name: 'خێرایی سێرڤەر', status: 'strong', text: `خێرایە (${speed}ms)`, percent: 95, desc: 'خێرایی باش.', solution: 'باشە.' });
    }
    if (aRec.AD === true) {
        items.push({ name: 'DNSSEC', status: 'strong', text: 'بەهێزە', percent: 100, desc: 'دژی ڕفاندنی DNS پارێزراوە.', solution: 'باشە.' });
    } else {
        items.push({ name: 'DNSSEC', status: 'medium', text: 'مامناوەند', percent: 40, desc: 'DNSSEC چالاک نەکراوە.', solution: 'لە پانێڵ چالاکی بکە.' });
    }
    const dmarcTxt = dmarcRec.Answer ? dmarcRec.Answer.map(a => a.data).join(' ') : '';
    if (dmarcTxt.toLowerCase().includes('v=dmarc1')) {
        items.push({ name: 'DMARC', status: 'strong', text: 'بەهێزە', percent: 100, desc: 'ڕێگری لە ئیمەیڵی ساختە.', solution: 'باشە.' });
    } else {
        items.push({ name: 'DMARC', status: 'weak', text: 'لاوازە', percent: 15, desc: 'DMARC نییە.', solution: 'تۆماری _dmarc زیاد بکە.' });
    }
    const txt = txtRec.Answer ? txtRec.Answer.map(a => a.data).join(' ') : '';
    if (txt.toLowerCase().includes('v=spf1')) {
        items.push({ name: 'SPF', status: 'strong', text: 'بەهێزە', percent: 100, desc: 'سێرڤەرە ڕێگەپێدراوەکان دیاری کراون.', solution: 'باشە.' });
    } else {
        items.push({ name: 'SPF', status: 'weak', text: 'لاوازە', percent: 30, desc: 'SPF نییە.', solution: 'v=spf1 زیاد بکە.' });
    }
    if (ipv6) {
        items.push({ name: 'IPv6', status: 'strong', text: 'بەهێزە', percent: 100, desc: 'پشتگیری IPv6.', solution: 'باشە.' });
    } else {
        items.push({ name: 'IPv6', status: 'medium', text: 'تەنها IPv4', percent: 50, desc: 'تەنها IPv4.', solution: 'AAAA زیاد بکە.' });
    }
    renderWebsiteReport(domain, ip, infoItems, items);
}

function renderWebsiteReport(domain, ip, infoItems, items) {
    const output = document.getElementById('mainOutputContainer');
    const weakItems = items.filter(i => i.status !== 'strong');
    const strongItems = items.filter(i => i.status === 'strong');
    const score = Math.round(items.reduce((a, b) => a + b.percent, 0) / items.length);
    let color = '#34d399';
    if (score < 85) color = '#fbbf24';
    if (score < 55) color = '#f87171';
    let html = `<div class="result-header-card"><div class="site-meta"><img class="favicon-img" src="https://www.google.com/s2/favicons?domain=${domain}&sz=128"><div><div class="domain-title">${domain}</div><div class="domain-subtitle">IP: ${ip}</div></div></div><div class="score-display"><div class="score-value" style="color: ${color};">${score}%</div><div class="score-label">ئاستی پاراستن</div></div></div>`;
    html += `<div class="section-heading" style="color: #93c5fd;">📋 زانیاری گشتی</div><div class="item-card info" style="margin-bottom: 30px;"><div style="padding: 0 5px;">`;
    infoItems.forEach(it => { html += `<div class="info-row"><span class="info-label">${it.label}</span><span class="info-value">${it.value}</span></div>`; });
    html += `</div></div>`;
    if (weakItems.length === 0) {
        html += `<div class="verified-banner"><div class="check-icon">✓</div><h2>پشتڕاستکراوە</h2><p>پیرۆزە! هیچ خاڵێکی لاواز نەدۆزرایەوە.</p></div>`;
    }
    if (weakItems.length > 0) {
        html += `<div class="section-heading" style="color: #fca5a5;">⚠️ خاڵە لاوازەکان (${weakItems.length})</div><div class="cards-grid">`;
        weakItems.forEach(i => {
            const isW = i.status === 'weak';
            html += `<div class="item-card ${isW ? '' : 'medium'}"><div class="item-top"><div class="item-name">${isW ? '🔴' : '🟠'} ${i.name}</div><span class="badge-status ${isW ? 'badge-weak' : 'badge-medium'}">${i.text}</span></div><p class="item-desc">${i.desc}</p><div class="progress-line"><div class="progress-fill" style="width: ${i.percent}%; background: ${isW ? '#f87171' : '#fbbf24'};"></div></div><div class="solution-box">💡 <strong>چارەسەر:</strong> ${i.solution}</div></div>`;
        });
        html += `</div>`;
    }
    if (strongItems.length > 0) {
        html += `<div class="section-heading" style="color: #6ee7b7; margin-top:35px;">✅ بەهێزەکان (${strongItems.length})</div><div class="cards-grid">`;
        strongItems.forEach(i => {
            html += `<div class="item-card strong"><div class="item-top"><div class="item-name">🟢 ${i.name}</div><span class="badge-status badge-strong">${i.text}</span></div><p class="item-desc">${i.desc}</p><div class="progress-line"><div class="progress-fill" style="width: 100%; background: #34d399;"></div></div></div>`;
        });
        html += `</div>`;
    }
    output.innerHTML = html;
}

/* ============================================================
   💻 CODE INSPECTION
   ============================================================ */
function loadSampleCode(type) {
    const box = document.getElementById('targetCodeInput');
    if (type === 1) {
        box.value = `<html>\n<head>\n    <title>سایتی تاقیکاری</title>\n</head>\n<body>\n    <img src="photo.jpg">\n    <a href="https://google.com" target="_blank">لینک</a>\n</body>\n</html>`;
    } else {
        box.value = `function calculate() {\n    let val = 50;\n    console.log(resul);\n}`;
    }
}

async function runCodeInspection() {
    if (!requireAuth('code')) return;
    if (!canUseCheck()) { showNoChecksAlert(); return; }
    const code = document.getElementById('targetCodeInput').value;
    const output = document.getElementById('mainOutputContainer');
    output.innerHTML = '';
    if (!code.trim()) { alert("تکایە کۆدێک دابنێ!"); return; }
    await useCheck();
    const lines = code.split('\n');
    const issues = [];
    lines.forEach((lineContent, index) => {
        const lineNum = index + 1;
        const trimmed = lineContent.trim();
        if (!trimmed) return;
        if (/<img\b(?![^>]*\balt=)[^>]*>/i.test(trimmed)) {
            issues.push({ title: 'نەبوونی alt بۆ وێنە', line: lineNum, code: trimmed, desc: 'تاگی <img> پێویستە altـی هەبێت.', fix: trimmed.replace('<img', '<img alt="وەسف"') });
        }
        if (trimmed.includes('target="_blank"') && !trimmed.includes('rel="noopener')) {
            issues.push({ title: 'لاوازی Target Blank', line: lineNum, code: trimmed, desc: 'پێویستی بە rel="noopener noreferrer" هەیە.', fix: trimmed.replace('target="_blank"', 'target="_blank" rel="noopener noreferrer"') });
        }
        if (trimmed.includes('getElementByID')) {
            issues.push({ title: 'هەڵەی ڕێنووس', line: lineNum, code: trimmed, desc: 'D دەبێت بچووک بێت.', fix: trimmed.replace('getElementByID', 'getElementById') });
        }
        if (/\bresul\b/.test(trimmed)) {
            issues.push({ title: 'هەڵە لە ناوی گۆڕاو', line: lineNum, code: trimmed, desc: 'دەبێت result بێت.', fix: trimmed.replace('resul', 'result') });
        }
    });
    if (issues.length === 0) {
        output.innerHTML = `<div class="verified-banner"><div class="check-icon">✓</div><h2>کۆدەکە پاکە</h2></div>`;
        return;
    }
    let html = `<div class="section-heading" style="color: #fca5a5;">⚠️ دۆزرایەوە ${issues.length} هەڵە</div>`;
    issues.forEach(item => {
        html += `<div class="item-card" style="margin-bottom: 18px;"><div class="item-top"><div style="font-weight: 800; font-size: 1.05rem;">❌ ${escapeHTML(item.title)}</div><span class="badge-status badge-weak">دێڕی ${item.line}</span></div><p class="item-desc">${escapeHTML(item.desc)}</p><div class="code-display-box">Line ${item.line}: ${escapeHTML(item.code)}</div><div class="fix-code-box"><div style="color: #6ee7b7; font-weight: 800; margin-bottom: 4px;">💡 کۆدی ڕاست:</div><div class="fix-code-inner">${escapeHTML(item.fix)}</div></div></div>`;
    });
    output.innerHTML = html;
}

/* ============================================================
   🛠️ HELPERS
   ============================================================ */
function escapeHTML(str) {
    if (!str) return '';
    return String(str).replace(/[&<>'"]/g, tag => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[tag]));
}