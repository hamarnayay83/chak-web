/* ============================================================
   👑 ADMIN.JS — پانێڵی ئەدمین
   ============================================================ */

const ADMIN_USERNAME = "hamaa";
const ADMIN_PASSWORD = "0011";
const STORAGE_KEYS = 'khama_website_keys_v1';

function adminLogin() {
    const u = document.getElementById('adminUsername').value.trim();
    const p = document.getElementById('adminPassword').value.trim();
    const msg = document.getElementById('loginMsg');
    if (u === ADMIN_USERNAME && p === ADMIN_PASSWORD) {
        sessionStorage.setItem('adminLoggedIn', 'true');
        document.getElementById('loginScreen').style.display = 'none';
        document.getElementById('adminPanel').style.display = 'block';
        loadKeys();
    } else {
        msg.className = 'admin-login-msg error';
        msg.textContent = '❌ ناوی بەکارهێنەر یان پاسوەرد هەڵەیە!';
    }
}

function logoutAdmin() {
    sessionStorage.removeItem('adminLoggedIn');
    location.reload();
}

function getKeys() {
    try {
        const raw = localStorage.getItem(STORAGE_KEYS);
        if (raw) {
            const data = JSON.parse(raw);
            return data.keys || [];
        }
    } catch (e) {
        console.warn('هەڵە لە خواندنی داتا:', e);
    }
    return [];
}

function saveKeys(keys) {
    const data = {
        keys: keys,
        lastUpdated: new Date().toISOString()
    };
    localStorage.setItem(STORAGE_KEYS, JSON.stringify(data));
}

function loadKeys() {
    let keys = getKeys();
    if (keys.length === 0) {
        fetch('keys.json')
            .then(r => {
                if (!r.ok) throw new Error('فایل نەدۆزرایەوە');
                return r.json();
            })
            .then(data => {
                if (data && data.keys && data.keys.length > 0) {
                    localStorage.setItem(STORAGE_KEYS, JSON.stringify(data));
                    renderKeysList(data.keys);
                } else {
                    renderKeysList([]);
                }
                document.getElementById('downloadPanel').style.display = 'block';
            })
            .catch(err => {
                console.log('keys.json نەدۆزرایەوە — دەستپێکردنی بەتاڵ:', err.message);
                renderKeysList([]);
                document.getElementById('downloadPanel').style.display = 'block';
            });
    } else {
        renderKeysList(keys);
        document.getElementById('downloadPanel').style.display = 'block';
    }
}

function generateRandomKey() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
    let k = '';
    for (let i = 0; i < 12; i++) k += chars.charAt(Math.floor(Math.random() * chars.length));
    return k;
}

function getDurationDays(plan) {
    const map = { 'day': 1, 'week': 7, 'month': 30, 'halfyear': 180, 'year': 365 };
    return map[plan] || 30;
}

function getPlanName(plan) {
    const map = { 'day': '١ ڕۆژ', 'week': '٧ ڕۆژ', 'month': '٣٠ ڕۆژ', 'halfyear': '٦ مانگ', 'year': '١ ساڵ' };
    return map[plan] || plan;
}

let lastCreatedKey = '';

function createNewKey() {
    try {
        const plan = document.getElementById('planSelect').value;
        const maxDevices = parseInt(document.getElementById('deviceSelect').value);
        const checksTotal = parseInt(document.getElementById('checkSelect').value);
        const customerName = document.getElementById('customerName').value.trim();
        let customKey = document.getElementById('customKey').value.trim();

        if (!customKey) customKey = generateRandomKey();
        if (customKey.length < 8) {
            alert('❌ کلیل دەبێت لانیکەم ٨ پیت بێت!');
            return;
        }

        const keys = getKeys();
        if (keys.some(k => k.key === customKey)) {
            alert('❌ ئەم کلیلە پێشتر بەکارهاتووە!');
            return;
        }

        const now = Date.now();
        const exp = now + getDurationDays(plan) * 24 * 60 * 60 * 1000;

        const newKey = {
            id: 'key_' + now + '_' + Math.random().toString(36).substring(2, 8),
            key: customKey,
            plan: plan,
            max_devices: maxDevices,
            customer_name: customerName,
            created_at: new Date(now).toISOString(),
            expires_at: new Date(exp).toISOString(),
            checks_total: checksTotal,
            checks_used: 0,
            active: true,
            devices: []
        };

        keys.unshift(newKey);
        saveKeys(keys);
        renderKeysList(keys);

        document.getElementById('customKey').value = '';
        document.getElementById('customerName').value = '';
        lastCreatedKey = customKey;
        document.getElementById('createdKeyValue').textContent = customKey;
        document.getElementById('createdKeyBox').style.display = 'block';
        document.getElementById('downloadPanel').style.display = 'block';

        copyToClipboard(customKey);
    } catch (err) {
        console.error('هەڵە لە دروستکردن:', err);
        alert('❌ هەڵە: ' + err.message);
    }
}

function copyCreatedKey() {
    if (lastCreatedKey) copyToClipboard(lastCreatedKey);
}

function copyToClipboard(text) {
    try {
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text);
        } else {
            const t = document.createElement('textarea');
            t.value = text;
            document.body.appendChild(t);
            t.select();
            document.execCommand('copy');
            document.body.removeChild(t);
        }
    } catch (e) {}
    showToast('✓ کۆپی کرا!');
}

function showToast(msg) {
    const n = document.createElement('div');
    n.textContent = msg;
    n.style.cssText = 'position:fixed;bottom:30px;left:50%;transform:translateX(-50%);background:linear-gradient(135deg,#34d399,#06b6d4);color:#fff;padding:14px 28px;border-radius:12px;font-weight:800;z-index:9999;font-family:Vazirmatn,sans-serif;';
    document.body.appendChild(n);
    setTimeout(() => n.remove(), 2000);
}

function renderKeysList(keys) {
    const listEl = document.getElementById('keysList');
    if (!keys || keys.length === 0) {
        listEl.innerHTML = `<div style="text-align:center; padding:30px; color:#64748b;"><div style="font-size:2rem; margin-bottom:10px;">🔑</div><p>هێشتا هیچ کلیلێک دروست نەکراوە</p></div>`;
        return;
    }

    let html = '';
    keys.forEach(key => {
        const now = Date.now();
        const expTime = new Date(key.expires_at).getTime();
        const isExpired = now > expTime;
        let badgeCls = 'admin-badge-active', badgeTxt = '✅ چالاک';
        if (!key.active) { badgeCls = 'admin-badge-inactive'; badgeTxt = '⛔ ناچالاک'; }
        else if (isExpired) { badgeCls = 'admin-badge-expired'; badgeTxt = '⏰ بەسەرچوو'; }

        const daysLeft = Math.ceil((expTime - now) / (1000 * 60 * 60 * 24));
        const daysText = daysLeft > 0 ? `${daysLeft} ڕۆژ ماوە` : 'بەسەرچووە';
        const devCount = (key.devices || []).length;
        const checksDisplay = key.checks_total === 99 ? '∞' : key.checks_total;

        html += `<div class="admin-key-item">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; flex-wrap:wrap; gap:10px;">
                <span class="admin-badge ${badgeCls}">${badgeTxt}</span>
                <span style="font-size:0.75rem; color:#64748b;">${key.customer_name ? '👤 ' + escapeHTML(key.customer_name) : 'بدوون ناو'}</span>
            </div>
            <div style="font-family:'JetBrains Mono',monospace; font-size:0.9rem; color:#7db8ff; margin-bottom:10px; direction:ltr; word-break:break-all;">
                🔑 ${escapeHTML(key.key)}
            </div>
            <div class="admin-key-stats">
                <div><strong>📅 ماوە</strong>${getPlanName(key.plan)}</div>
                <div><strong>⏳ کاتی ماوە</strong>${daysText}</div>
                <div><strong>📱 ئامێر</strong>${devCount} / ${key.max_devices}</div>
                <div><strong>🔐 چەیک</strong>${key.checks_used} / ${checksDisplay}</div>
            </div>
            <div style="display:flex; gap:8px; flex-wrap:wrap;">
                <button class="admin-btn admin-btn-toggle" onclick="toggleKeyActive('${key.id}')">${key.active ? '⛔ ناچالاککردن' : '✅ چالاککردن'}</button>
                <button class="admin-btn admin-btn-danger" onclick="deleteKey('${key.id}')">🗑️ سڕینەوە</button>
            </div>
        </div>`;
    });
    listEl.innerHTML = html;
}

function toggleKeyActive(id) {
    const keys = getKeys();
    const k = keys.find(x => x.id === id);
    if (!k) return;
    k.active = !k.active;
    saveKeys(keys);
    renderKeysList(keys);
}

function deleteKey(id) {
    if (!confirm('ئایا دڵنیایت لە سڕینەوەی ئەم کلیلە؟')) return;
    const keys = getKeys().filter(x => x.id !== id);
    saveKeys(keys);
    renderKeysList(keys);
}

function clearAllKeys() {
    if (!confirm('⚠️ ئایا دڵنیایت لە سڕینەوەی هەموو کلیلەکان؟')) return;
    saveKeys([]);
    renderKeysList([]);
}

function downloadKeysJSON() {
    const keys = getKeys();
    const data = {
        keys: keys,
        lastUpdated: new Date().toISOString()
    };
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'keys.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('✅ keys.json دابەزێنرا! بۆ Netlify ئەپلۆدی بکەرەوە');
}

function escapeHTML(s) {
    if (!s) return '';
    return String(s).replace(/[&<>'"]/g, t => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', "'":'&#39;', '"':'&quot;' }[t]));
}

window.addEventListener('DOMContentLoaded', () => {
    if (sessionStorage.getItem('adminLoggedIn') === 'true') {
        document.getElementById('loginScreen').style.display = 'none';
        document.getElementById('adminPanel').style.display = 'block';
        loadKeys();
    }
    document.getElementById('adminPassword').addEventListener('keypress', e => {
        if (e.key === 'Enter') adminLogin();
    });
});