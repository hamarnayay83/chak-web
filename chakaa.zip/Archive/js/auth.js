/* ============================================================
   🔐 AUTH.JS — چوونەژوورەوە بە کلیل
   ============================================================ */

const STORAGE_KEYS = 'khama_website_keys_v1';

function getDeviceId() {
    let deviceId = localStorage.getItem('deviceId');
    if (!deviceId) {
        deviceId = 'dev_' + Math.random().toString(36).substring(2) + Date.now().toString(36);
        localStorage.setItem('deviceId', deviceId);
    }
    return deviceId;
}

async function loadKeys() {
    const raw = localStorage.getItem(STORAGE_KEYS);
    if (raw) {
        try { return JSON.parse(raw).keys || []; } catch (e) {}
    }
    try {
        const res = await fetch('keys.json');
        const data = await res.json();
        localStorage.setItem(STORAGE_KEYS, JSON.stringify(data));
        return data.keys || [];
    } catch (e) {
        return [];
    }
}

async function saveKeys(keys) {
    const data = { keys: keys, lastUpdated: new Date().toISOString() };
    localStorage.setItem(STORAGE_KEYS, JSON.stringify(data));
}

async function verifyKey() {
    const input = document.getElementById('passKeyInput');
    const btn = document.getElementById('submitBtn');
    const keyValue = input.value.trim();

    if (!keyValue) {
        showMessage('error', '❌ تکایە کلیلێک بنووسە!');
        return;
    }

    btn.disabled = true;
    btn.textContent = '⏳ خەریکی پشکنینین...';

    try {
        const keys = await loadKeys();
        const found = keys.find(k => k.key === keyValue);

        if (!found) {
            showMessage('error', '❌ کلیلەکە نادروستە یان هەڵە لە نووسینیدا هەیە.');
            resetBtn(btn);
            return;
        }

        if (!found.active) {
            showMessage('error', '⛔ ئەم کلیلەیە ناچالاک کراوە. تکایە پەیوەندی بکە بە ئەدمین.');
            resetBtn(btn);
            return;
        }

        const now = Date.now();
        const expTime = new Date(found.expires_at).getTime();
        if (now > expTime) {
            showMessage('error', '⏰ ئەم کلیلەیە بەسەرچووە. تکایە کلیلێکی نوێ بکڕە.');
            resetBtn(btn);
            return;
        }

        const currentDeviceId = getDeviceId();
        let usedDevices = found.devices || [];

        if (!usedDevices.includes(currentDeviceId)) {
            if (usedDevices.length >= found.max_devices) {
                showMessage('error', `📱 ئەم کلیلەیە بۆ ${found.max_devices} ئامێر تەرخان کراوە و بەکارهێنراوە.`);
                resetBtn(btn);
                return;
            }
            usedDevices.push(currentDeviceId);
            found.devices = usedDevices;
            await saveKeys(keys);
        }

        const checksLeft = found.checks_total === 99 ? 99 : Math.max(0, found.checks_total - found.checks_used);

        const session = {
            keyId: found.id,
            keyValue: found.key,
            plan: found.plan,
            expiresAt: expTime,
            deviceId: currentDeviceId,
            loginAt: now,
            checksLeft: checksLeft,
            checksUsed: found.checks_used,
            checksTotal: found.checks_total
        };
        localStorage.setItem('userSession', JSON.stringify(session));

        const daysLeft = Math.ceil((expTime - now) / (1000 * 60 * 60 * 24));
        const checksDisplay = found.checks_total === 99 ? '∞' : checksLeft;

        showMessage('success', `✅ بەخێربێیت! ${daysLeft} ڕۆژ ماوە | 🔍 ${checksDisplay} چەیک ماوە`);

        const checksInfoBox = document.getElementById('checksInfoBox');
        checksInfoBox.style.display = 'block';
        checksInfoBox.textContent = `🔍 چەیک: ${checksDisplay} ماوە (${found.checks_used} بەکارهاتوو)`;

        setTimeout(() => {
            const redirect = localStorage.getItem('redirectAfterAuth') || 'site';
            localStorage.removeItem('redirectAfterAuth');
            window.location.href = 'index.html?view=' + redirect;
        }, 1500);

    } catch (err) {
        console.error(err);
        showMessage('error', '❌ هەڵەیەک ڕوویدا. تکایە دووبارە هەوڵ بدە.');
        resetBtn(btn);
    }
}

function resetBtn(btn) {
    btn.disabled = false;
    btn.textContent = '✓ پشتڕاستکردنەوە و چوونەژوورەوە';
}

function showMessage(type, text) {
    const msg = document.getElementById('messageBox');
    msg.className = 'auth-message ' + type;
    msg.textContent = text;
    msg.style.display = 'block';
}

document.getElementById('passKeyInput').addEventListener('keypress', e => {
    if (e.key === 'Enter') verifyKey();
});